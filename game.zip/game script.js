const cells = document.querySelectorAll('.cell');
const statusText = document.getElementById('status');

let currentPlayer = 'X';
let gameActive = true;
let gameState = ['', '', '', '', '', '', '', '', ''];

// Win combinations
const winCombinations = [
  [0, 1, 2], [3, 4, 5], [6, 7, 8],
  [0, 3, 6], [1, 4, 7], [2, 5, 8],
  [0, 4, 8], [2, 4, 6]
];

// Handle move
function handleMove(cellIndex) {
  if (gameActive && gameState[cellIndex] === '') {
    gameState[cellIndex] = currentPlayer;
    cells[cellIndex].innerText = currentPlayer;
    checkResult();
    currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
  }
}

// Check result
function checkResult() {
  let roundWon = false;
  for (let i = 0; i < winCombinations.length; i++) {
    const [a, b, c] = winCombinations[i];
    if (gameState[a] !== '' && gameState[a] === gameState[b] && gameState[a] === gameState[c]) {
      roundWon = true;
      break;
    }
  }

  if (roundWon) {
    statusText.innerText = `${currentPlayer} wins!`;
    gameActive = false;
    return;
  }

  if (!gameState.includes('')) {
    statusText.innerText = `It's a draw!`;
    gameActive = false;
    return;
  }

  statusText.innerText = `Player ${currentPlayer}'s turn`;
}

// Reset game
function resetGame() {
  gameState = ['', '', '', '', '', '', '', '', ''];
  currentPlayer = 'X';
  gameActive = true;
  statusText.innerText = `Player ${currentPlayer}'s turn`;
  cells.forEach(cell => cell.innerText = '');
}
